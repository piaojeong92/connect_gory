package kr.ac.a20110548.rsstest;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Park on 2016-04-18.
 */
public class NewsAdapter extends ArrayAdapter<NewsInfo> {
    protected LayoutInflater inflater = null;
    private ArrayList<NewsInfo> mNewsInfo = null;

    public NewsAdapter(Context context, int resource, ArrayList<NewsInfo> mNewsInfo) {
        super(context, resource);
        inflater = LayoutInflater.from(context);
        this.mNewsInfo = mNewsInfo;
    }

    @Override
    public int getCount() {
        return mNewsInfo.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        NewsViewHolder nvh = null;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.news_list, parent, false);
            nvh = new NewsViewHolder();
            nvh.txTitle = (TextView) convertView.findViewById(R.id.title);
            nvh.txContent = (TextView) convertView.findViewById(R.id.content);
            convertView.setTag(nvh);
        } else {
            nvh = (NewsViewHolder) convertView.getTag();
        }

        NewsInfo info = mNewsInfo.get(position);
        if (info != null) {
            nvh.txTitle.setText("제목 : "+ info.getTitle());
            nvh.txContent.setText(info.getContent());
        }
        return convertView;
    }
}
