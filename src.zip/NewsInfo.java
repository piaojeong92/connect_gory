package kr.ac.a20110548.rsstest;

/**
 * Created by Park on 2016-04-18.
 */
public class NewsInfo {
    String title;
    String content;

    public NewsInfo(String title, String content) {
        this.title = title;
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }
}