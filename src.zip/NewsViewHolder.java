package kr.ac.a20110548.rsstest;

import android.widget.TextView;

/**
 * Created by Park on 2016-04-18.
 */

public class NewsViewHolder{
    TextView txTitle;
    TextView txContent;
}

